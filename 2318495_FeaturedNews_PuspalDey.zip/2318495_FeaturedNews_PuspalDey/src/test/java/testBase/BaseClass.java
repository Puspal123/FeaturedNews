package testBase;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;
import java.util.Properties;

public class BaseClass {
	
	// Declaring the required variables
	public static WebDriver driver;
	public Properties property;
	
	// Declaring the setup method to launch the browser and navigate to the URL 
	// Declaring the setup method as a BeforeTest so it will run once before running all the test cases
	@BeforeTest
	@Parameters({"browser"})
	public void setup(String browser) throws IOException {
		// Launching the required browser as per the parameter
		switch(browser.toLowerCase()) {
			case "chrome": driver = new ChromeDriver();
			break;
			case "edge": driver = new EdgeDriver();
			break;
			default: System.out.println("No matching browser found"); 
			return;
		}
		
		// Creating an object of the FileReader class to read the properties file
		FileReader file = new FileReader(".//src/test/resources/config.properties");
		property = new Properties();
		property.load(file);	// Loading the properties file
		
		driver.manage().deleteAllCookies();								 	// Clearing all the cookies
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));	// Adding implicit wait of 30 seconds
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(30));	// Adding page load timeout of 30 seconds
		
		// Getting the URL from the config.properties file and launching it
		driver.navigate().to(property.getProperty("appURL"));	
		driver.manage().window().maximize();								// Maximizing the browser window
	}
	
	/*
	 *  Declaring the teardown method as the AfterTest method which will close the driver instance and will
	 *  run only once after running all the test cases
	*/
	@AfterTest
	public void teardown() {
		driver.quit();			// Closing the driver
	}
	
	public String captureScreen(String name) throws IOException{
		String timeStamp = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
		
		TakesScreenshot takesScreenshot = (TakesScreenshot) driver;
		File sourceFile = takesScreenshot.getScreenshotAs(OutputType.FILE);
		
		String targetFilePath = System.getProperty("user.dir")+"\\screenshots\\" + name + "_" + timeStamp + ".png";
		File targetFile = new File(targetFilePath);
		
		sourceFile.renameTo(targetFile);
		
		return targetFilePath;
	}
}
