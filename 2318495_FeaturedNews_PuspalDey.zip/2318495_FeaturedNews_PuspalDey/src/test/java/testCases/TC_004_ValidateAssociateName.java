package testCases;

import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.NewsPage;
import testBase.BaseClass;
import utilities.AddFluentWait;
import utilities.ScreenShot;

public class TC_004_ValidateAssociateName extends BaseClass {
	// Creating an object of the AddFluentWait class to call the wait methods
	public AddFluentWait wait = new AddFluentWait();
	public ScreenShot screenShot = new ScreenShot();
	
	@Test
	public void validateAssociateName() {
		try {
			// Creating an object of the NewsPage page object class to call the action methods
			NewsPage newsPage = new NewsPage(driver);
			
			// Storing the associate name of the news author
			String associateName = newsPage.getAssociateName();
			
			// Hovering over to the associate name for the popup to show
			newsPage.hoverOverAssociateName();
			screenShot.takeScreenShot(driver);

			// Checking if the associate name is present within the popup
			boolean isNamePresent = newsPage.isAssociateNamePresentInPopup();
			
			// Validating the presence of the associate name in the popup
			Assert.assertTrue(isNamePresent);
			System.out.println("!!! Validation Successful - Associate Name present in the popup !!!");
			
			// Extracting the associate name shown in the popup
			newsPage.hoverOverAssociateNameInPopup();
			String associateNameInPopup = newsPage.getAssociateNameInPopup();
			
			// Hovering over the news header for the popup to close
			newsPage.hoverOnNewsHeader();
			
			// Printing the Associate name shown in the news and visible in the popup
			System.out.println("Associate Name in news: " + associateName);
			System.out.println("Associate Name in popup: " + associateNameInPopup);
			
			// Validating if both the associate names are same or not
			Assert.assertEquals(associateName, associateNameInPopup);
			System.out.println("!!! Associate name matches with the associate name in the popup !!! \n");
		}
		catch(Exception e) {
			System.out.println("Associate Name not found. \n");
		}
	}
}
