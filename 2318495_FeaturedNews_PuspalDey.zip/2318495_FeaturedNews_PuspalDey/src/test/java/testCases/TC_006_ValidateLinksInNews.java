package testCases;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import pageObjects.NewsPage;
import testBase.BaseClass;
import utilities.AddFluentWait;

public class TC_006_ValidateLinksInNews extends BaseClass {
	// Creating an object of the AddFluentWait class to call the wait methods
	public AddFluentWait wait = new AddFluentWait();
	//SoftAssert softAssert = new SoftAssert();
	
	@Test
	public void validateLinks() throws IOException {
				// Creating an object of the NewsPage page object class to call the action methods
				NewsPage newsPage = new NewsPage(driver);
			
				// Creating a list of all the links in the present within the news
				List<WebElement> links = newsPage.getLinksInNews();
			
				// Getting the number of links
				int numberOfLinks = links.size();
				int validLinks = 0;
				
				// Using the for loop to validate the links present in the news article
				for(WebElement link: links) {
					// Storing the link in the form of a String
					String hrefValue = link.getAttribute("href");
					
					// Checking if the link has valid href attribute
					if(hrefValue == null || hrefValue.isEmpty()) {
						System.out.println("Href is Empty");
						continue;
					}
					else if(hrefValue.endsWith("page-not-found.asp")) {
						System.out.println("Page not found");
						continue;
					}
					
					// Declaring an object of the URLConnection
					URLConnection connection;
					
					// Declaring an object of the HttpURLConnection
					HttpURLConnection httpConnection = null;
					
					// Casting the URLConnection to HttpURLConnection
					try {
						URL url = new URL(hrefValue);
						connection = url.openConnection();
						httpConnection = (HttpURLConnection) connection;
						httpConnection.connect();
					}
					catch(Exception e) {
						
					}
					
					// Counting the number of valid links
					try {
						if(httpConnection.getResponseCode() <= 200 || httpConnection.getResponseCode() == 403) {
							validLinks++;
						}
						else {
							continue;	
						}
					}
					catch(Exception e) {
						
					}
				}
				System.out.println("Total number of links present in the news: " + numberOfLinks);
				System.out.println("Total number of valid links present in the news: " + validLinks);
	}
}
