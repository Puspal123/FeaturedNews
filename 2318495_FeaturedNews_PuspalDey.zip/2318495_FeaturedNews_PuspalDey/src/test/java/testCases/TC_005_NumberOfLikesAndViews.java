package testCases;

import org.testng.annotations.Test;

import pageObjects.NewsPage;
import testBase.BaseClass;
import utilities.AddFluentWait;
import utilities.ScreenShot;

public class TC_005_NumberOfLikesAndViews extends BaseClass {
	// Creating an object of the AddFluentWait class to call the wait methods
	public AddFluentWait wait = new AddFluentWait();
	public ScreenShot screenShot = new ScreenShot();
	
	@Test
	public void getLikesAndViews() throws InterruptedException {
		// Creating an object of the NewsPage page object class to call the action methods
		NewsPage newsPage = new NewsPage(driver);
		
		// Scrolling down to the Social Bar for extracting likes and views
		newsPage.scrollToSocialBar();
		
		// Calling the wait method for the social bar element to be visible
		wait.waitForSocialBar(driver);
		
		// Waiting for the social bar to completely load
		Thread.sleep(5000);
		
		// Extracting the number of likes and views
		String numberOfLikes = newsPage.getNumberOfLikes();
		String numberOfViews = newsPage.getNumberOfViews();
		screenShot.takeScreenShot(driver);
		
		// Printing the number of likes and views
		System.out.println("Number of Likes: " + numberOfLikes);
		System.out.println("Number of Views: " + numberOfViews);
	}
}
