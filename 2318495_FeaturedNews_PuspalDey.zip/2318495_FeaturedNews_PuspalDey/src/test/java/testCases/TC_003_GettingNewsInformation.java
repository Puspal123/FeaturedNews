package testCases;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.HomePage;
import pageObjects.NewsPage;
import testBase.BaseClass;
import utilities.AddFluentWait;

public class TC_003_GettingNewsInformation extends BaseClass {
	// Creating an object of the AddFluentWait class to call the wait methods
	public AddFluentWait wait = new AddFluentWait();
	
	// Creating an object of the ValidateAssociateName class to call the validation method
	public TC_004_ValidateAssociateName validation = new TC_004_ValidateAssociateName();
	
	// Creating an object of the NumberOfLikesAndViews class to capture the likes and views of the news
	public TC_005_NumberOfLikesAndViews likesAndViews = new TC_005_NumberOfLikesAndViews();
	
	// Creating an object of the ValidateLinksInNews class to call the validation method
	public TC_006_ValidateLinksInNews links = new TC_006_ValidateLinksInNews();
	
	// Creating an object of the ValidateShareOption class to call the validation method and capture the option within the share menu
	public TC_007_ValidateShareOption share = new TC_007_ValidateShareOption();
	
	@Test
	public void getNewsInformation() {
		try {
			// Creating an object of the HomePage page object class to call the action methods
			HomePage homePage = new HomePage(driver);
			
			// Creating a list of the WebElements of the news in the featured news section
			List<WebElement> newsElements = homePage.featuredNewsSection();
			
			// Using for loop to get all the required information of the featured news
			for(int i = 0; i< newsElements.size(); i++) {
				// Creating an object of the Actions class to perform different mouse and keyboard actions
				Actions action = new Actions(driver);
				
				// Hovering over to the news element
				action.moveToElement(newsElements.get(i)).perform();
				
				// Clicking on the news element
				action.click(newsElements.get(i)).perform();
				
				System.out.println("News details: " + (i+1) + "\n");
				
				// Calling the method to wait for the news header to display
				wait.waitForNewsHeader(driver);
				
				// Calling the validation method of the ValidateAssociateName class to verify the associate name of the news
				validation.validateAssociateName();
				
				// Creating an object of the NewsPage page object class to call the action methods
				NewsPage newsPage = new NewsPage(driver);
				
				// Storing the body of the news article within a string and printing in the console
				String newsDetails = newsPage.getNewsInformation();
				System.out.println(newsDetails + "\n");
				
				// Calling the method of the NumberOfLikesAndViews class to extract the likes and views of the news
				likesAndViews.getLikesAndViews();
				
				// Calling the method of the ValidateShareOption class to verify if the share option is present or not and printing the share options
				share.validateShareOption();
				
				// Calling the method of the ValidateLinksInNews class to validate the links present in the news article
				try {
					links.validateLinks();	
				}
				catch(Exception e) {
					
				}
				
				// Adding extra lines to format the output in the console
				System.out.println("\n");
					
				// Navigating back to homepage
				newsPage.navigateBack();
			}
		}
		catch(Exception e) {
			Assert.fail(e.getMessage());
		}
	}
}
