package testCases;

import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.HomePage;
import testBase.BaseClass;
import utilities.AddFluentWait;
import utilities.ScreenShot;

public class TC_001_CaptureUserInformation extends BaseClass {
	// Creating an object of the AddFluentWait class to call the wait methods
	public AddFluentWait wait = new AddFluentWait();
	// Creating an object of the ScreenShot class to take the necessary screenshots
	public ScreenShot screenShot = new ScreenShot();
	
	@Test
	public void captureUserInformation() {
		try {
			// Creating an object of the HomePage class
			HomePage homePage = new HomePage(driver);
			
			// Waiting for the User Icon to appear
			wait.waitForUserInformation(driver); 
			
			// Clicking the User Icon button
			homePage.clickUserIcon();
			
			// Waiting for the User Details to appear
			wait.waitForUserDetails(driver);

			// Printing the username and email of the user
			System.out.println("Username is: " + homePage.getUserName());
			System.out.println("User email is: " + homePage.getUserEmail());
			
			// Printing an extra line for formatting the output in console
			System.out.println();
			
			// Taking the screenshot of the user details
			screenShot.takeScreenShot(driver);
			
			// Refreshing the home page
			homePage.refreshPage();
		}
		catch(Exception e) {
			System.out.println("User Information not found");
			Assert.fail(e.getMessage());
		}
	}
}
