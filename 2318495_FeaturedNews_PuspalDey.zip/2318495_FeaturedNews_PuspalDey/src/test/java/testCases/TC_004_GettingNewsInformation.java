package testCases;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import pageObjects.HomePage;
import pageObjects.NewsPage;
import testBase.BaseClass;
import utilities.AddFluentWait;

public class TC_004_GettingNewsInformation extends BaseClass {
	
	public AddFluentWait wait = new AddFluentWait();
	public TC_003_ValidateAssociateName validation = new TC_003_ValidateAssociateName();
	public TC_005_NumberOfLikesAndViews likesAndViews = new TC_005_NumberOfLikesAndViews();
	public TC_006_ValidateLinksInNews links = new TC_006_ValidateLinksInNews();
	public TC_007_ValidateShareOption share = new TC_007_ValidateShareOption();
	
	@Test
	public void getNewsInformation() {
		try {
			HomePage homePage = new HomePage(driver);
			List<WebElement> newsElements = homePage.featuredNewsSection();
			
			for(int i = 0; i< newsElements.size(); i++) {
				Actions action = new Actions(driver);
				action.moveToElement(newsElements.get(i)).perform();
				action.click(newsElements.get(i)).perform();
				
				System.out.println("News details: " + (i+1) + "\n");
				
				wait.waitForNewsHeader(driver);
				validation.validateAssociateName();
				
				NewsPage newsPage = new NewsPage(driver);
				String newsDetails = newsPage.getNewsInformation();
				System.out.println(newsDetails + "\n");
				
				likesAndViews.getLikesAndViews();
				share.validateShareOption();
				try {
					links.validateLinks();	
				}
				catch(Exception e) {
					
				}
				
				System.out.println("\n");
					
				newsPage.navigateBack();
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
}
