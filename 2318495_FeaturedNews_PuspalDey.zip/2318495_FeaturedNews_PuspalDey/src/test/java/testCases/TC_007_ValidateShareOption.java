package testCases;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.NewsPage;
import testBase.BaseClass;
import utilities.AddFluentWait;
import utilities.ScreenShot;

public class TC_007_ValidateShareOption extends BaseClass {
	
	public AddFluentWait wait = new AddFluentWait();
	public ScreenShot screenShot = new ScreenShot();
	
	@Test
	public void validateShareOption() {
		try {
			// Creating an object of the NewsPage page object class to call the action methods
			NewsPage newsPage = new NewsPage(driver);
			
			// Scrolling to the Share Button
			newsPage.scrollToShareButton();
			
			// Checking if the share button is present
			boolean isShareOptionPresent = newsPage.isShareButtonPresent();
			if(isShareOptionPresent) {
				System.out.println("Share Option is present");
			}
			else {
				System.out.println("Share Option is not present");
			}
			
			// Clicking on the share button
			newsPage.clickShareButton();
			screenShot.takeScreenShot(driver);
			
			// Storing the options within the share button in a list
			List<WebElement> shareOptions = newsPage.getShareOptions();
			int size = shareOptions.size();
			
			// Printing the options within the Share option
			String shareOption;
			for(int  i = 0; i < size; i++) {
					shareOption = shareOptions.get(i).getText();
					System.out.println(shareOption);
			}
			
			// Validating if the Share option is present
			Assert.assertTrue(isShareOptionPresent);
		}
		catch(Exception e) {
			Assert.fail(e.getMessage());
		}
	}
}
