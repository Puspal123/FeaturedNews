package testCases;

import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.NewsPage;
import testBase.BaseClass;
import utilities.AddFluentWait;

public class TC_003_ValidateAssociateName extends BaseClass {
	
	public AddFluentWait wait = new AddFluentWait();
	
	@Test
	public void validateAssociateName() {
		try {
			NewsPage newsPage = new NewsPage(driver);
			String associateName = newsPage.getAssociateName();
			
			newsPage.hoverOverAssociateName();

			boolean isNamePresent = newsPage.isAssociateNamePresentInPopup();
			Assert.assertTrue(isNamePresent);
			
			newsPage.hoverOverAssociateNameInPopup();
			String associateNameInPopup = newsPage.getAssociateNameInPopup();
			
			newsPage.hoverOnNewsHeader();
			
			System.out.println("Associate Name in news: " + associateName);
			System.out.println("Associate Name in popup: " + associateNameInPopup + "\n");
			
			Assert.assertEquals(associateName, associateNameInPopup);
		}
		catch(Exception e) {
			System.out.println("Associate Name not found. \n");
		}
	}
}
