package testCases;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.HomePage;
import testBase.BaseClass;
import utilities.AddFluentWait;
import utilities.ScreenShot;

public class TC_002_ValidateNewsHeader extends BaseClass {
	// Creating an object of the AddFluentWait class to call the wait methods
	public AddFluentWait wait = new AddFluentWait();
	public ScreenShot screenShot = new ScreenShot();
	
	@Test
	public void validateNewsHeader() {
		try {
			// Calling the wait method to wait for the first news of the featured news section to be visible
			wait.waitForFirstNewsElement(driver);
			
			// Creating an object of the HomePage page object class to call the action methods
			HomePage homePage = new HomePage(driver);
			
			// Checking if the first news is visible or not
			boolean isNewsPresent = homePage.isNewsPresent();
			
			// Assertion for validating if the news is present
			Assert.assertTrue(isNewsPresent);
			screenShot.takeScreenShot(driver);
			
			// Creating a list with all the news elements in the featured news section
			List<WebElement> newsElements = homePage.featuredNewsSection();
			
			// Using for loop to validate if the news header and news tooltips of the featured news in the home page matches or not
			for(int i = 0; i < newsElements.size(); i++) {
				// Creating the list of the news headers
				List<String> newsHeaders = homePage.getNewsHeaders();
				// Creating the list of the news tooltips
				List<String> newsTooltips = homePage.getNewsTooltips();
				
				// Printing the news headers and tooltips
				System.out.println("News Header " + (i+1) + ": " + newsHeaders.get(i));
				System.out.println("News Tooltips " + (i+1) + ": " + newsTooltips.get(i));
				// Printing an extra line for formatting the output in console
				
				// Assertion to validate if the news headers and tooltips matches for the respective news
				Assert.assertEquals(newsHeaders.get(i), newsTooltips.get(i));
				System.out.println("!!! News headers and News Tooltips are matching !!!");
			}
			// Printing an extra line for formatting the output in console
			System.out.println();
		}
		catch(Exception e) {
			System.out.println("Featured News not available");
			Assert.fail(e.getMessage());
		}
	}
}
