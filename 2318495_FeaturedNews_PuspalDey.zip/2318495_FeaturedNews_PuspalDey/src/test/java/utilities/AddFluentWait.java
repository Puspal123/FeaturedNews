package utilities;

import java.time.Duration;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;

public class AddFluentWait {
	public FluentWait<WebDriver> wait;
	
	// Waiting for the Help button on the HomePage
	public void waitForUserInformation(WebDriver driver) {
		wait = new FluentWait<WebDriver> (driver);
		wait.withTimeout(Duration.ofSeconds(25));
		wait.pollingEvery(Duration.ofSeconds(5));
		wait.ignoring(NoSuchElementException.class);
		
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.id("O365_MainLink_Help_container")));
	}
	
	// Waiting for the UserDetails section to open on the homepage
	public void waitForUserDetails(WebDriver driver) {
		wait = new FluentWait<WebDriver> (driver);
		wait.withTimeout(Duration.ofSeconds(25));
		wait.pollingEvery(Duration.ofSeconds(5));
		wait.ignoring(NoSuchElementException.class);
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("mectrl_currentAccount_primary")));
	}
	
	// Waiting for the first news element in the Featured News section
	public void waitForFirstNewsElement(WebDriver driver) {
		wait = new FluentWait<WebDriver> (driver);
		wait.withTimeout(Duration.ofSeconds(25));
		wait.pollingEvery(Duration.ofSeconds(5));
		wait.ignoring(NoSuchElementException.class);
		
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("(//div[contains(@class , 'newsItem__hero')]/a[@data-automation-id = 'newsItemTitle'])[1]")));
	}
	
	// Waiting for the news header in the news page
	public void waitForNewsHeader(WebDriver driver) {
		wait = new FluentWait<WebDriver> (driver);
		wait.withTimeout(Duration.ofSeconds(25));
		wait.pollingEvery(Duration.ofSeconds(5));
		wait.ignoring(NoSuchElementException.class);
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role = 'heading']")));
	}
	
	// Waiting for the Associate name popup
	public void waitForAssociatePopup(WebDriver driver) {
		wait = new FluentWait<WebDriver> (driver);
		wait.withTimeout(Duration.ofSeconds(25));
		wait.pollingEvery(Duration.ofSeconds(5));
		wait.ignoring(NoSuchElementException.class);
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='presentation']//h1")));
	}
	
	// Waiting for the Social bar of likes and views
	public void waitForSocialBar(WebDriver driver) {
		wait = new FluentWait<WebDriver> (driver);
		wait.withTimeout(Duration.ofSeconds(25));
		wait.pollingEvery(Duration.ofSeconds(5));
		wait.ignoring(NoSuchElementException.class);
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id = 'CommentsWrapper']")));
	}
}
