package pageObjects;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;

import testBase.BasePage;

public class HomePage extends BasePage{
	// Constructor for the HomePage
	public HomePage(WebDriver driver) {
		super(driver);
	}
	
	// Locating the WebElements
	// 'Help button' on the homepage
	@FindBy(id = "O365_MainLink_Help_container")
	WebElement helpButton;
	
	// 'User Profile' button on the homepage
	@FindBy(id = "meInitialsButton")
	WebElement userAccountButton;
	
	// Section where user details is shown
	@FindBy(id = "mectrl_currentAccount_primary")
	WebElement userDetails;
	
	// Element displaying the username of the associate
	@FindBy(xpath = "//div[@id = 'mectrl_currentAccount_primary']")
	WebElement userName;
	
	// Element displaying the email id of the associate
	@FindBy(xpath = "//div[@id = 'mectrl_currentAccount_secondary']")
	WebElement userEmail;
	
	// The first news element in the featured news section
	@FindBy(xpath = "(//div[contains(@class , 'newsItem__hero')]/a[@data-automation-id = 'newsItemTitle'])[1]")
	WebElement firstNewsElement;
	
	// List of all the news elements in the featured news section
	@FindBy(xpath = "//div[contains(@class , 'newsItem__hero')]/a[@data-automation-id = 'newsItemTitle']")
	static List<WebElement> featuredNews;
	
	// Action Methods
	// Method to click on the 'User Profile' button
	public void clickUserIcon() {
		Actions action = new Actions(driver);
		action.moveToElement(userAccountButton).perform();
		action.doubleClick(userAccountButton).perform();
	}
	
	// Method to extract the username from the user details
	public String getUserName() {
		String user = userName.getText();
		return user;
	}
	
	// Method to extract the email id from the user details
	public String getUserEmail() {
		String email = userEmail.getText();
		return email;
	}
	
	// Method to refresh the web page
	public void refreshPage() {
		driver.navigate().refresh();
	}
	
	// Method to check if the 'Featured News' section is present or not
	public boolean isNewsPresent() {
		boolean isNewsPresent = firstNewsElement.isDisplayed();
		return isNewsPresent;
	}
	
	// Method to create the list of all the elements in the 'Featured News' section
	public List<WebElement> featuredNewsSection(){
		return featuredNews;
	}
		
	// Method to store the headers of each news in the 'Featured News' section in a list
	public List<String> getNewsHeaders(){
		List<String> newsHeaders = new ArrayList<String>();
		Actions action = new Actions(driver);
		for(int i = 0; i < featuredNews.size(); i++) {
			action.moveToElement(featuredNews.get(i)).perform();
			newsHeaders.add(i, featuredNews.get(i).getText());
		}
		return newsHeaders;
	}
	
	// Method to store the tooltips of each news in the 'Featured News' section in a list
	public List<String> getNewsTooltips(){
		List<String> newsTooltips = new ArrayList<String>();
		Actions action = new Actions(driver);
		for(int i = 0; i < featuredNews.size(); i++) {
			action.moveToElement(featuredNews.get(i)).perform();
			newsTooltips.add(i, featuredNews.get(i).getAttribute("title"));
		}
		return newsTooltips;
	}
}
