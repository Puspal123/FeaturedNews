package pageObjects;

import java.util.List;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import testBase.BasePage;
import utilities.AddFluentWait;

public class NewsPage extends BasePage {
	// Creating an object of the AddFluentWait class to call the wait methods
	public AddFluentWait wait = new AddFluentWait();
	
	// Creating an object of the Actions class to perform various mouse and keyboard actions
	public Actions action = new Actions(driver);
	
	JavascriptExecutor js = (JavascriptExecutor)(driver);
	
	// Creating the Constructor of the NewsPage class
	public NewsPage(WebDriver driver) {
		super(driver);
	}
	
	// Locating the required WebElements
	// Element displaying the header of the news in the news page
	@FindBy(xpath = "//div[@role = 'heading']")
	WebElement newsHeader;
	
	// Element with the news article
	@FindBy(how = How.TAG_NAME, using = "article")
	WebElement article;
	
	// Element displaying the Associate name of the writer of the news
	@FindBy(xpath = "//div[@data-automation-id = 'personaDetails']/div[1]")
	WebElement associateName;
	
	// Element displaying the Associate name in the popup when hovered over
	@FindBy(xpath = "//div[@role='presentation']//h1")
	WebElement associateNameInPopup;
	
	// Element displaying the count of likes for the news
	@FindBy(xpath = "//button[@data-automation-id = 'sp-socialbar-likedbymessage']//span[contains(@class, 'ms-Button-label')]")
	WebElement likeCount;
	
	// Element displaying the count of views for the news
	@FindBy(xpath = "//button[@data-automation-id = 'sp-socialbar-viewcount']//span[contains(@class, 'ms-Button-label')]")
	WebElement viewCount;
	
	// Element displaying the likes, views, comments of the news
	@FindBy(xpath = "//div[@id = 'CommentsWrapper']")
	WebElement socialBar;
	
	// List of all the hyperlinks present within the news
	@FindBy(xpath = "//div[@data-automation-id = 'CanvasSection']//a")
	static List<WebElement> linksInNews;
	
	// Element displaying the Share button in the news page
	@FindBy(xpath = "(//span[@data-automationid = 'splitbuttonprimary'])[12]")
	WebElement shareButton;
	
	//  List of all the options available within the Share option
	@FindBy(xpath = "//ul[@role = 'presentation']//button")
	static List<WebElement> shareOptions;
	
	// Action Methods
	// Method to extract the news from the news article
	public String getNewsInformation() {
		String newsDetails = article.getText();
		return newsDetails;
	}
	
	// Method to navigate back to the homepage
	public void navigateBack() {
		driver.navigate().back();
	}
	
	// Method to extract the associate name from the news page
	public String getAssociateName() {
		return associateName.getText();
	}
	
	// Method to hover over the associate name and waiting for the popup to display
	public void hoverOverAssociateName() {
		action.moveToElement(associateName).perform();
		wait.waitForAssociatePopup(driver);
	}
	
	// To check if the associate name is present in the popup
	public boolean isAssociateNamePresentInPopup() {
		boolean isNamePresent = associateNameInPopup.isDisplayed();
		return isNamePresent;
	}
	
	// Method to hover over the associate name on the popup so that we can extract the name
	public void hoverOverAssociateNameInPopup() {
		action.moveToElement(associateNameInPopup).perform();
	}
	
	// Method to extract the associate name displayed in the popup
	public String getAssociateNameInPopup() {
		return associateNameInPopup.getText();
	}
	
	// Method to hover over the news header for the popup to vanish
	public void hoverOnNewsHeader() {
		action.moveToElement(newsHeader).perform();
	}
	
	// Method for scrolling down to the social bar section for extracting the likes and views
	public void scrollToSocialBar() {
		js.executeScript("arguments[0].scrollIntoView();", socialBar);	
	}
	
	// Method for extracting the number of likes on the news
	public String getNumberOfLikes() {
		String[] likes = likeCount.getText().split(" ");
		return likes[0];
	}
	
	// Method for extracting the number of views on the news
	public String getNumberOfViews() {
		String[] views = viewCount.getText().split(" ");
		return views[0];
	}
		
	// Method to return the list of all the hyperlinks present in the news
	public List<WebElement> getLinksInNews(){
		return linksInNews;
	}
	
	// Method to scroll to the share button
	public void scrollToShareButton() {
		js.executeScript("arguments[0].scrollIntoView();", shareButton);	
	}
	
	// Method to check if the share button is present or not
	public boolean isShareButtonPresent() {
		return shareButton.isDisplayed();	
	}
	
	// Method to click on the share button
	public void clickShareButton() {
		shareButton.click();
	}
	
	// Method to return the options within the share menu as a list
	public List<WebElement> getShareOptions(){
		return shareOptions;
	}
}
